/* eslint-disable */
export interface Part {
  selector: string
}

export interface Parts {
  [key: string]: Part
}
