/* eslint-disable */
import type { SlotRecipeCreatorFn } from '../types/recipe';

export declare const sva: SlotRecipeCreatorFn