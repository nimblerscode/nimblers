/* eslint-disable */
import type { RecipeCreatorFn } from '../types/recipe';

export declare const cva: RecipeCreatorFn

export type { RecipeVariant, RecipeVariantProps } from '../types/recipe';