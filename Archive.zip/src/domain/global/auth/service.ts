import type { Session, User } from "better-auth";
import { Context, type Effect, Schema as S } from "effect";
import type { Email } from "../email/model";
import type { UserNotFoundError } from "../user/model";
import type { Account } from "./model";

// === Errors ===

export class InvalidCredentialsError extends S.TaggedError<InvalidCredentialsError>()(
  "InvalidCredentialsError",
  {},
) {}

export class AccountNotFoundError extends S.TaggedError<AccountNotFoundError>()(
  "AccountNotFoundError",
  { userId: S.String, providerId: S.String },
) {}

// Placeholder for generic DB errors
export class DbError extends S.TaggedError<DbError>()("DbError", {
  message: S.String,
  cause: S.optional(S.Unknown),
}) {}

export type AuthRepoError = UserNotFoundError | AccountNotFoundError | DbError;

// Placeholder Error for high-level auth failures
export class AuthServiceError extends S.TaggedError<AuthServiceError>()(
  "AuthServiceError",
  { message: S.String, cause: S.optional(S.Unknown) },
) {}

// Email verification specific errors
export class EmailVerificationError extends S.TaggedError<EmailVerificationError>()(
  "EmailVerificationError",
  { message: S.String, cause: S.optional(S.Unknown) },
) {}

export class EmailAlreadyVerifiedError extends S.TaggedError<EmailAlreadyVerifiedError>()(
  "EmailAlreadyVerifiedError",
  { email: S.String },
) {}

export class UserNotAuthenticatedError extends S.TaggedError<UserNotAuthenticatedError>()(
  "UserNotAuthenticatedError",
  {},
) {}

export type AuthSessionError =
  | UserNotFoundError
  | AccountNotFoundError
  | DbError;

// === Service Interfaces (Ports) using Context.GenericTag ===

// --- Auth Repository Port ---

// Type alias for input data when creating an account
export type AccountData = Omit<Account, "id" | "createdAt" | "updatedAt">;

// --- Auth Service Port (Abstraction over better-auth) ---
// Define the Tag using GenericTag and the interface
export class AuthService extends Context.Tag("core/auth/AuthService")<
  AuthService,
  {
    readonly handler: () => Effect.Effect<Response, AuthServiceError>;
    readonly getSession: () => Effect.Effect<
      { session: Session; user: User },
      AuthServiceError
    >;
  }
>() {}

// --- Email Verification Use Case ---
export class EmailVerificationUseCase extends Context.Tag(
  "@core/auth/EmailVerificationUseCase",
)<
  EmailVerificationUseCase,
  {
    readonly resendVerificationEmail: (
      userEmail: Email,
    ) => Effect.Effect<
      void,
      EmailVerificationError | EmailAlreadyVerifiedError
    >;
  }
>() {}
