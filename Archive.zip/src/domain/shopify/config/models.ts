export interface ShopifyConfig {
  clientId: string;
}
