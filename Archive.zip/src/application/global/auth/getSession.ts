import type { User as BetterAuthUser, Session } from "better-auth";
import { Effect } from "effect";
import {
  AuthService,
  type AuthServiceError,
} from "@/domain/global/auth/service";

export const getSession = (): Effect.Effect<
  { session: Session; user: BetterAuthUser },
  AuthServiceError,
  AuthService
> =>
  Effect.gen(function* (_) {
    const authService = yield* _(AuthService);
    const result = yield* _(authService.getSession());
    return result;
  });
