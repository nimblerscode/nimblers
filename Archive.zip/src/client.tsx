import { initClient } from "rwsdk/client";

initClient();
