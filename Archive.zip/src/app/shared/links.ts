import { defineLinks } from "rwsdk/router";

export const link = defineLinks(["/"]);
