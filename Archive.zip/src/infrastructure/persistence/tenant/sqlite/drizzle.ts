// Import the correct tenant schema

// Use the correct drizzle imports for Durable Objects SQLite
import {
  type DrizzleSqliteDODatabase,
  drizzle,
} from "drizzle-orm/durable-sqlite";
import { migrate } from "drizzle-orm/durable-sqlite/migrator";
import { Context, Effect, Layer } from "effect";
import * as tenantSchema from "@/infrastructure/persistence/tenant/sqlite/schema";
// @ts-ignore
import migrations from "../../../../../drizzle/tenant/migrations.js";

// === Context Tags ===

/**
 * Tag for the Durable Object's state, providing access to its storage.
 */
export const DurableObjectState = Context.GenericTag<DurableObjectState>(
  "infra/do/DurableObjectStorage",
);

/**
 * Tag for the Drizzle instance connected to the DO's internal SQLite DB.
 * Use the correct type from drizzle-orm/durable-sqlite.
 */
export const DrizzleSqliteDODatabaseTag = Context.GenericTag<
  DrizzleSqliteDODatabase<typeof tenantSchema>
>("infra/db/DrizzleSqliteDODatabase");

export class DrizzleDOClient extends Context.Tag("infra/db/DrizzleDOClient")<
  DrizzleDOClient,
  {
    readonly migrate: () => Effect.Effect<void, Error>;
    readonly db: DrizzleSqliteDODatabase<typeof tenantSchema>;
  }
>() {}

// === Live Layers ===

/**
 * Provides the Drizzle client connected to the Durable Object's internal SQLite DB.
 *
 * This layer depends on DurableObjectStorage.
 * It initializes the Drizzle client using the durable-sqlite driver
 * and runs database migrations on scope creation.
 */
export const DrizzleDOClientLive = Layer.scoped(
  DrizzleDOClient,
  Effect.gen(function* () {
    const doState = yield* DurableObjectState;
    const db = drizzle(doState.storage, {
      schema: tenantSchema,
      logger: true,
    });

    return {
      db,
      migrate: () =>
        Effect.gen(function* () {
          yield* Effect.tryPromise({
            try: () =>
              doState.blockConcurrencyWhile(async () => {
                try {
                  await migrate(db, migrations);
                } catch (error) {
                  throw new Error(
                    `Drizzle migration failed: ${
                      error instanceof Error ? error.message : String(error)
                    }`,
                  );
                }
              }),
            catch: (error) => {
              return new Error(
                `Migration wrapper failed: ${
                  error instanceof Error ? error.message : String(error)
                }`,
              );
            },
          });
        }),
    };
  }),
);

const schema = tenantSchema;

export { schema };
