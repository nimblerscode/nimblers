import journal from './meta/_journal.json';
import m0000 from './0000_slimy_mongu.sql?raw';

export default {
  journal,
  migrations: {
    m0000
  }
}
