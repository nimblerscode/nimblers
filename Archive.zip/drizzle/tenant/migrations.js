import journal from './meta/_journal.json';
import m0000 from './0000_marvelous_terror.sql?raw';

export default {
  journal,
  migrations: {
    m0000
  }
}
