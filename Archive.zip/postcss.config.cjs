module.exports = {
  plugins: {
    "@pandacss/dev/postcss": {},
  },
};
